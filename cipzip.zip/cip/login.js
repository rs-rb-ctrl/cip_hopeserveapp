document.addEventListener("DOMContentLoaded", () => {
    const registerForm = document.getElementById("registerForm");
    const loginForm = document.getElementById("loginForm");
    const logoutButton = document.getElementById("logout");
    
    if (registerForm) {
        registerForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            localStorage.setItem("user", JSON.stringify({ username, password }));
            alert("Registration successful! Redirecting to login...");
            window.location.href = "login.html";
        });
    }
    
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const loginUsername = document.getElementById("loginUsername").value;
            const loginPassword = document.getElementById("loginPassword").value;
            const storedUser = JSON.parse(localStorage.getItem("user"));
            
            if (storedUser && storedUser.username === loginUsername && storedUser.password === loginPassword) {
                localStorage.setItem("isAuthenticated", "true"); // Mark as logged in
                alert("Login successful! Redirecting to dashboard...");
                window.location.href = "dashboard.html";
            } else {
                alert("Invalid credentials!");
            }
        });
    }
    
    if (logoutButton) {
        logoutButton.addEventListener("click", () => {
            localStorage.removeItem("isAuthenticated"); // Clear session
            alert("Logged out successfully!");
            window.location.href = "login.html";
        });
    }
    
    // Restrict dashboard access if not logged in
    if (window.location.pathname.includes("dashboard.html")) {
        const isAuthenticated = localStorage.getItem("isAuthenticated");
        if (!isAuthenticated) {
            alert("You must be logged in to access the dashboard!");
            window.location.href = "login.html";
        }
    }
});