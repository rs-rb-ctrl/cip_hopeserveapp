document.getElementById("donorForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const name = document.getElementById("orgName").value;
    const amount = document.getElementById("foodAmount").value;
    const type = document.getElementById("foodType").value;
    const people = document.getElementById("peopleCount").value;
    const date = document.getElementById("donationDate").value;
  
    const donation = {
      name,
      amount,
      type,
      people,
      date,
    };
  
    displayScheduledDonation(donation);
    this.reset();
  });
  
  function displayScheduledDonation(donation) {
    const container = document.getElementById("scheduledDonations");
  
    const card = document.createElement("div");
    card.classList.add("donation-card");
    card.innerHTML = `
      <h4>${donation.name}</h4>
      <p><strong>Food:</strong> ${donation.type} (${donation.amount} kg)</p>
      <p><strong>Serves:</strong> ${donation.people} people</p>
      <p><strong>Date:</strong> ${donation.date}</p>
    `;
  
    container.appendChild(card);
  }
  