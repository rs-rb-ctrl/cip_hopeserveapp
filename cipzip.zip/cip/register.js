// script.js

document.getElementById("registerForm").addEventListener("submit", function(e) {
    e.preventDefault(); // Prevent default form submission
  
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
  
    // You can add simple validation or save to localStorage if needed
    // For now, just redirect after a fake registration
  
    alert("Registration successful!");
  
    // Redirect to login page
    window.location.href = "index.html";
  });
  